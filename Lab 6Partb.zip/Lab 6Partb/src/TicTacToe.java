//Utsav Acharya
//LAB 6 PArt B
// 3/1/2025
import javax.swing.*;
import java.awt.*;

public class TicTacToe {
    /**
     * Main method that setup game window and initilize the graphical components like grid and status label
     * @param args
     */
    public static void main(String[] args) {
        //Create JFrame named as MainWindow
        JFrame MainWindow = new JFrame("Tic Tac Toe");
        MainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        MainWindow.setSize(300, 300);
        MainWindow.setLayout(new BorderLayout());

        //Create a panel for the 3x3 grid for buttons
        JPanel buttonPanel = new JPanel();
        //Create Grid
        buttonPanel.setLayout(new GridLayout(3, 3));

        //Create a status label for the game
        JLabel statusLabel = new JLabel("Player 1's turn");

        // Create an instance of the TicTacToeGame class to handle game logic
        MainGame game = new MainGame(statusLabel);

        //Create buttons using a for loop
        for (int i = 1; i <= 9; i++) {
            JButton button = new JButton(String.valueOf(i));
            /**
             * Reference taken from oracle library
             * @link https://docs.oracle.com/javase/8/docs/api/index.html?javax/swing/BorderFactory.html
             */

            button.setBorder(BorderFactory.createEtchedBorder());
            button.setFocusPainted(false);
            button.addActionListener(game);
            //Adding the button to the grid panel
            buttonPanel.add(button);
        }

        //Add the components to the MainWindow JFrame
        MainWindow.add(buttonPanel);
        MainWindow.add(statusLabel, BorderLayout.SOUTH);

        //Make the MainWindow JFrame visible
        MainWindow.setVisible(true);
    }
}
