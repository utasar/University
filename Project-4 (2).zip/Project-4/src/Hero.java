public class Hero extends Actor{

}
