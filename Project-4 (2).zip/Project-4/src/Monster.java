public class Monster extends Actor{
}
