# Project Title
Catacomb Crawler
## Project Description
Describe what the purpose of the project is. Include what it does in
summary
:
"Catacomb Crawler" is a text-based dungeon-crawling game where the user controls a hero
navigating through a randomly generated catacomb . Objectives of the game is for the 
hero to reach the southeast corner of the catacomb while battling monster and avoiding death

and what programming concepts it reinforces
The project reinforces key object-oriented programming (OOP) concepts, including:

Classes and objects
Inheritance and polymorphism
Randomization
Method creation and interaction
User input handling and control flow
## Project Guide
All guides was give in PDF in Dropbox where we need to go as pdf guidelines 
### Dependencies
To run your code, what does a user need to have installed?
Installed Java Development kit (jdk) : latest version
you can use vscode or intelij for writing and run the code .
install java extensions in app

### How to run the project
If they have things installed, how can they run your project?
the zip files share by user or the clone project repository to your machine download
open the files
compile  CatacombCrawler.java class
Run the class 
create your hero and chose size of above 5
### How to play the game
Tell a user how to play your game. Be sure to add special details if
you
Create hero
Catacomb Size 
Movement of hero to different direction north ,south ,east or west.
Battle ( where hero monster fights and lose there health get damage until they dies)
teasure to boost health in different number of rooms 
Exit must be southeast corner to win the game 
game over if heros health reaches to 0
implemented something extra!
in every move shows the monster nearby ,
each game is different cause random placement of monster
hero's health 0 game ends
teasure let hero to last longer 
## Lessons Learned
Tell us what you learned along the way. Examples include:
UML 
polymorphism and inheritance 
randomization 
game logic 
bug fixing 
- what concepts you practiced / better understood
- Used of abtraction 
- handling random events
- control flow and game loop
- bugs you detangled
- handling the health boost (finds the treasure before .)
  Use an abstract class.
  