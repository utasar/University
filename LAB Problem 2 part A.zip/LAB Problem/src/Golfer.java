public class Golfer {
    // Fields
    private String firstName;
    private String lastName;
    private int score;
    private int holesCompleted;

    // Constructor to initialize the fields
    public Golfer(String firstName, String lastName, int score, int holesCompleted) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.score = score;
        this.holesCompleted = holesCompleted;
    }

    // toString method to return the desired output format
    @Override
    public String toString() {
        return lastName + ", " + firstName + ":" + score + " with " + holesCompleted + " holes completed";
    }
}
