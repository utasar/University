public class Golfer implements Comparable<Golfer> {
    private String firstName;
    private String lastName;
    private int score;
    private int holesCompleted;

    // Constructor to initialize the fields
    public Golfer(String firstName, String lastName, int score, int holesCompleted) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.score = score;
        this.holesCompleted = holesCompleted;
    }

    // toString method to return the desired output format
    @Override
    public String toString() {
        return lastName + ", " + firstName + ":" + score + " with " + holesCompleted + " holes completed";
    }

    // Implementing the compareTo method for Comparable interface
    @Override
    public int compareTo(Golfer other) {
        // 1. Compare by score first (more negative score comes first)
        if (this.score != other.score) {
            return Integer.compare(this.score, other.score);  // More negative score comes first
        }

        // 2. If scores are the same, compare by holes completed (higher is better)
        if (this.holesCompleted != other.holesCompleted) {
            return Integer.compare(other.holesCompleted, this.holesCompleted);  // More holes completed comes first
        }

        // 3. If both score and holes completed are the same, compare lexicographically by last name (ignoring case)
        int lastNameComparison = this.lastName.compareToIgnoreCase(other.lastName);
        if (lastNameComparison != 0) {
            return lastNameComparison;  // Lexicographical comparison by last name
        }

        // 4. If both score, holes completed, and last name are the same, compare lexicographically by first name (ignoring case)
        return this.firstName.compareToIgnoreCase(other.firstName);  // Lexicographical comparison by first name
    }
}
